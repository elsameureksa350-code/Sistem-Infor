<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Dashboard Admin - Pandawa</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Bootstrap Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

 <style>
    :root {
      --bg-light: linear-gradient(to bottom right, #f0f4ff, #e8f0ff);
      --bg-dark: #0b1a2d;
      --text-dark: #212529;
      --text-light: #f8f9fa;
      --card-light: #ffffff;
      --card-dark: #162447;
    }

    body {
      background: var(--bg-light);
      overflow-x: hidden;
      font-family: 'Poppins', sans-serif;
      transition: all 0.3s ease;
    }

    body.dark-mode {
      background: var(--bg-dark);
      color: var(--text-light);
    }

    #wrapper {
      display: flex;
      width: 100%;
      transition: all 0.3s ease;
    }

    /* Sidebar */
    #sidebar-wrapper {
      width: 250px;
      background: linear-gradient(180deg, #004aad, #0077ff);
      color: white;
      transition: all 0.3s ease;
      min-height: 100vh;
    }

    #sidebar-wrapper .sidebar-heading {
      font-weight: 700;
      font-size: 1.5rem;
      text-align: center;
      padding: 25px 0;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }

    #sidebar-wrapper .list-group-item {
      border: none;
      padding: 15px 25px;
      color: #eaeaea;
      background: transparent;
      transition: 0.3s;
    }

    #sidebar-wrapper .list-group-item:hover,
    #sidebar-wrapper .list-group-item.active {
      background-color: rgba(255, 255, 255, 0.15);
      color: #fff;
      transform: translateX(5px);
    }

    #sidebar-wrapper.tutup {
      margin-left: -250px;
    }

    /* Page content */
    #page-content-wrapper {
      flex: 1;
      transition: all 0.3s ease;
    }

    nav.navbar {
      background: #fff;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    body.dark-mode nav.navbar {
      background: #162447;
      color: #fff;
    }

    .card {
      border-radius: 15px;
      transition: 0.3s;
      background: var(--card-light);
    }

    .dark-mode .card {
      background: var(--card-dark);
      color: var(--text-light);
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
    }

    .card-header {
      background: transparent;
      font-weight: 600;
      border-bottom: 2px solid #0077ff33;
    }

    #menu-toggle {
      border: none;
      background: transparent;
      font-size: 1.5rem;
    }

    .dark-mode table {
      color: #fff;
    }

    @media (max-width: 768px) {
      #sidebar-wrapper {
        position: fixed;
        height: 100%;
        z-index: 1000;
      }
    }
  </style>
</head>

<body>
  <div class="d-flex" id="wrapper">
    <!-- Sidebar -->
    <div id="sidebar-wrapper">
      <div class="sidebar-heading text-center py-4 fs-4 border-bottom">📚 PANDAWA</div>
      <div class="list-group list-group-flush my-3">
        <a href="dashboardadmin.html" class="list-group-item list-group-item-action active">
          <i class="bi bi-speedometer2 me-2"></i> Dashboard
        </a>
        <a href="Daftarbuku.html" class="list-group-item list-group-item-action">
          <i class="bi bi-book me-2"></i> Data Buku
        </a>
        <a href="Dataanggota.html" class="list-group-item list-group-item-action">
          <i class="bi bi-people me-2"></i> Data Anggota
        </a>
        <a href="#" class="list-group-item list-group-item-action">
          <i class="bi bi-arrow-left-right me-2"></i> Peminjaman
        </a>
        <a href="#" class="list-group-item list-group-item-action">
          <i class="bi bi-gear me-2"></i> Pengaturan
        </a>
      </div>
    </div>

    <!-- Konten Utama -->
    <div id="page-content-wrapper">
      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <div class="container-fluid">
          <button class="btn btn-outline-dark" id="menu-toggle"><i class="bi bi-list"></i></button>
          <h5 class="ms-3 my-auto">Dashboard Admin</h5>

          <ul class="navbar-nav ms-auto">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle text-dark" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                <i class="bi bi-person-circle"></i> Admin
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#">Profil</a></li>
                <li><a class="dropdown-item" href="#">Logout</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </nav>

      <!-- Isi Dashboard -->
      <div class="container-fluid px-4 py-4">
        <div class="row g-4">
          <div class="col-md-3">
            <div class="card shadow-sm border-0">
              <div class="card-body">
                <h6 class="card-title text-secondary"><a href="Daftarbuku.html">Total Buku</a></h6>
                <h3 class="fw-bold">20</h3>
                <i class="bi bi-book-half fs-2 text-primary"></i>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow-sm border-0">
              <div class="card-body">
                <h6 class="card-title text-secondary">Pengunjung</h6>
                <h6 class="card-title text-secondary"><a href="#">Total Pengunjung perhari</a></h6>
                <h6 class="card-title text-secondary"><a href="#">Total Pengunjung perbulan</a></h6>
                <i class="bi bi-people-fill fs-2 text-success"></i>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow-sm border-0">
              <div class="card-body">
                <h6 class="card-title text-secondary">Pinjaman</h6>
                <h6 class="card-title text-secondary"><a href="#">Total Pinjaman perhari</a></h6>
                <h6 class="card-title text-secondary"><a href="#">Total Pinjaman perbulan</a></h6>
                <i class="bi bi-arrow-left-right fs-2 text-warning"></i>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card shadow-sm border-0">
              <div class="card-body">
                <h6 class="card-title text-secondary">Pengembalian</h6>
                <h6 class="card-title text-secondary"><a href="#">Total Pengembalian perhari</a></h6>
                <h6 class="card-title text-secondary"><a href="#">Total Pengembalian perbulan</a></h6>
                <i class="bi bi-exclamation-triangle fs-2 text-danger"></i>
              </div>
            </div>
          </div>
        </div>

        <div class="row mt-5">
          <div class="col-lg-7">
            <div class="card shadow-sm border-0">
              <div class="card-header bg-white fw-bold">Statistik Peminjaman Buku</div>
              <div class="card-body">
                <canvas id="chartPeminjaman"></canvas>
              </div>
            </div>
          </div>

          <div class="col-lg-5">
            <div class="card shadow-sm border-0">
              <div class="card-header bg-white fw-bold">Daftar Buku Terbaru</div>
              <div class="card-body">
                <ul class="list-group list-group-flush">
                  <li class="list-group-item">Belajar JavaScript - John Doe</li>
                  <li class="list-group-item">Pemrograman Web Lanjut - Siti Aminah</li>
                  <li class="list-group-item">Data Science untuk Pemula - Budi Raharjo</li>
                  <li class="list-group-item">AI dan Machine Learning - A. Wijaya</li>
                  <li class="list-group-item">Matematika Komputasi - Rina K.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Script -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    // Tombol buka/tutup sidebar
    const menuToggle = document.getElementById("menu-toggle");
    const sidebarWrapper = document.getElementById("sidebar-wrapper");

    menuToggle.addEventListener("click", () => {
      sidebarWrapper.classList.toggle("tutup");
    });

    // Grafik Chart.js
    const ctx = document.getElementById("chartPeminjaman");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun"],
        datasets: [{
          label: "Jumlah Peminjaman",
          data: [120, 90, 150, 80, 170, 200],
          backgroundColor: "rgba(54, 162, 235, 0.6)",
          borderRadius: 8
        }]
      },
      options: {
        responsive: true,
        scales: { y: { beginAtZero: true } }
      }
    });
  </script>
</body>
</html>

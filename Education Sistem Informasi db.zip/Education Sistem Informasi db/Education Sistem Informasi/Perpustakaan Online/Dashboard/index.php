<?php
session_start();
require_once '../config.php';
if (isset($_POST['btnRegister'])) {
    $username = $_POST['reg_username'];
    $email = $_POST['reg_email'];
    $password = $_POST['reg_password'];

    $cekUser = mysqli_query($koneksi, "SELECT * FROM login WHERE username='$username'");
    if (mysqli_num_rows($cekUser) > 0) {
        echo "<script>alert('Username sudah terdaftar, gunakan username lain!');history.go(-1);</script>";
    } else {
      $insert = mysqli_query($koneksi, "INSERT INTO login (username, email, password, role, created) 
                                  VALUES ('$username', '$email', MD5('$password'), 'user', NOW())");
        if ($insert) {
            echo "<script>alert('Registrasi Berhasil! Silahkan Login');window.location='login.php';</script>";
        } else {
            echo "<script>alert('Registrasi Gagal!');history.go(-1);</script>";
        }
    }
}

if (isset($_POST['btnLogin'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query cek user
    $sql = "SELECT * FROM login WHERE username='$username' AND password=MD5('$password')";
    $result = mysqli_query($koneksi, $sql);
    $ada = mysqli_num_rows($result);

    if ($ada > 0) {
        $data = mysqli_fetch_assoc($result);

        $_SESSION['username'] = $data['username'];
        $_SESSION['role'] = $data['role'];

        if ($data['role'] == 'admin') {
            header("Location: Manajemen Koleksi/dashboardadmin.php");
        } else {
            header("Location: dashboard1.php");
        }
        exit();
    } else {
        echo "<script>alert('Login Gagal: Cek username dan password Anda!');history.go(-1);</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login / Register Form</title>
    <link rel="stylesheet" href="login.css" />
    <link
      href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="container">
      <div class="form-box login">
        <form action="" method="POST">
          <h1>Login</h1>
          <div class="input-box">
            <input type="text" name="username" placeholder="Username" required />
            <i class="bx bxs-user"></i>
          </div>
          <div class="input-box">
            <input type="password" name="password" placeholder="Password" required />
            <i class="bx bxs-lock-alt"></i>
          </div>

          <button type="submit" name="btnLogin" class="btn">Login</button>
          <p>or login with social platforms</p>
          <div class="social-icons">
            <a href="#"><i class="bx bxl-google"></i></a>
            <a href="#"><i class="bx bxl-facebook"></i></a>
            <a href="#"><i class="bx bxl-github"></i></a>
            <a href="#"><i class="bx bxl-linkedin"></i></a>
          </div>
        </form>
      </div>

<div class="form-box register">
  <form action="" method="POST">
    <h1>Registration</h1>
    <div class="input-box">
      <input type="text" name="reg_username" placeholder="Username" required />
      <i class="bx bxs-user"></i>
    </div>
    <div class="input-box">
      <input type="email" name="reg_email" placeholder="Email" required />
      <i class="bx bxs-envelope"></i>
    </div>
    <div class="input-box">
      <input type="password" name="reg_password" placeholder="Password" required />
      <i class="bx bxs-lock-alt"></i>
    </div>
    <button type="submit" name="btnRegister" class="btn">Register</button>
  </form>
</div>


      <div class="toggle-box">
        <div class="toggle-panel toggle-left">
          <h1>Hello, Welcome!</h1>
          <p>Don't have an account?</p>
          <button class="btn register-btn">Register</button>
        </div>

        <div class="toggle-panel toggle-right">
          <h1>Welcome Back!</h1>
          <p>Already have an account?</p>
          <button class="btn login-btn">Login</button>
        </div>
      </div>
    </div>

    <script src="script3.js"></script>
  </body>
</html>

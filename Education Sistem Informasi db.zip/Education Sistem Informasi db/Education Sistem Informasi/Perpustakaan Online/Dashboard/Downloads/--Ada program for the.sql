--Ada program for the
--favorite number algorithm
WITH TEXT_IO;
PROCEDURE FavoriteNumber IS
PACKAGE INT_IO IS NEW TEXT_IO.INTEGER_IO(INTEGER);
n :INTEGER;
--user's favorite number
BEGIN
--Get the user's favorite number
TEXT_IO.PUT("What is your favorite number?");
INT_IO.GET(n);
--Compute the next number
n :=n +1;
--Write the output
TEXT_IO.NEW_LINE;
TEXT_IO.PUT("My favorite number is 1 more than that,");
INT_IO.PUT(n,4);
TEXT_IO.NEW_LINE;
TEXT_IO.NEW_LINE;
END FavoriteNumber;
Ada program for favorite number
<?php
include 'koneksi.php';
session_start();

if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h2>Register</h2>

    <form action="" method="POST">
        <input type="text" name="username" placeholder="Username" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="password" name="password" placeholder="Password" required><br>

        <button type="submit" name="register">Daftar</button>
    </form>

    <p>Sudah punya akun? <a href="index.php">Login</a></p>
</div>

</body>
</html>

<?php
if (isset($_POST['register'])) {
    $username  = $_POST['username'];
    $email     = $_POST['email'];
    $password  = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $check = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username' OR email='$email'");

    if (mysqli_num_rows($check) > 0) {
        echo "<script>alert('Username atau email sudah dipakai!');</script>";
    } else {
        mysqli_query($koneksi, "INSERT INTO users(username, email, password) VALUES('$username','$email','$password')");
        echo "<script>alert('Registrasi berhasil! Silakan login.'); window.location='index.php';</script>";
    }
}
?>

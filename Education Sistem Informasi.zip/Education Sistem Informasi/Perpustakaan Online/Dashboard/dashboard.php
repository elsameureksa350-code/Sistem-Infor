<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="dashboard">

    <aside class="sidebar">
        <h2>My Dashboard</h2>
        <ul>
            <li><a href="dashboard.php">🏠 Home</a></li>
            <li><a href="#">📊 Statistik</a></li>
            <li><a href="#">📁 Data User</a></li>
            <li><a href="#">⚙️ Pengaturan</a></li>
            <li><a href="logout.php">🚪 Logout</a></li>
        </ul>
    </aside>

    <main class="content">
        <h1>Selamat Datang, <span><?php echo $_SESSION['username']; ?></span> 👋</h1>

        <div class="cards">

            <div class="card">
                <h3>Total User</h3>
                <p>124</p>
            </div>

            <div class="card">
                <h3>Pengunjung Hari Ini</h3>
                <p>56</p>
            </div>

            <div class="card">
                <h3>Aktifitas</h3>
                <p>22 Task</p>
            </div>

        </div>

        <h2>Grafik Aktivitas</h2>
        <img src="https://quickchart.io/chart?c={type:'bar',data:{labels:['Sen','Sel','Rab','Kam','Jum'],datasets:[{label:'Aktivitas',data:[5,8,6,10,4]}]}}" width="450">

    </main>

</div>

</body>
</html>

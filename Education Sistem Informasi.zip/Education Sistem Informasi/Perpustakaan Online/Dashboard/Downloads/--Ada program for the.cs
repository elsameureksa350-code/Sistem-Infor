//C++pragram for the
//favorite mumber algorithm
tinelude ciostream
using nanespace std;
yoid main()
一
lnt ni //user'g favorlte nunber
//get the user's favorite number
caut 5s "What is your favorite number?";
c1n??ni
/fcompute the next number
nmn*1;